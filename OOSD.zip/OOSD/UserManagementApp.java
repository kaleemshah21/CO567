import java.time.LocalDateTime;
import java.util.*;
public class UserManagementApp {
    private static List<User> users = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        //initialise a set of events
        List<Event> events = Arrays.asList(
            new Event("E001", "Concert A", LocalDateTime.of(2024, 12, 20, 19, 0)),
            new Event("E002", "Play B", LocalDateTime.of(2024, 12, 25, 18, 30)),
            new Event("E003", "Stand-up Comedy", LocalDateTime.of(2024, 12, 15, 20, 0)),
            new Event("E004", "Orchestra", LocalDateTime.of(2025, 1, 5, 18, 0))
        );
        Event.setEvents(events);

        //application loop, handles user choices e.g. login, signup or quit
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Login");
            System.out.println("2. Signup");
            System.out.println("3. Quit");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }
            //switch case for each choice
            switch (choice) {
                case 1:
                    User loggedInUser = User.login(users, scanner);
                    if (loggedInUser instanceof Customer) {
                        homePage((Customer) loggedInUser);
                    } else {
                        System.out.println("Only customers can access this section.");
                    }
                    break;
                case 2:
                    User.signup(users, scanner);
                    break;
                case 3:
                    System.out.println("Exiting the program. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    //handles homepage, allows options for viewing shows by date and upcoming as well as logging out.
    private static void homePage(Customer loggedInCustomer) {
        while (true) {
            System.out.println("\nHome Page:");
            System.out.println("1. View shows by date range");
            System.out.println("2. View upcoming shows");
            System.out.println("3. Logout");
            System.out.print("Enter your choice: ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            //switch case for each choice
            switch (choice) {
                case 1:
                    loggedInCustomer.viewShowsByDateRange(scanner);  // Call the method in Customer
                    break;
                case 2:
                    loggedInCustomer.viewUpcomingShowsAndSeatingChart(scanner);  // Call the method in Customer
                    break;
                case 3:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
