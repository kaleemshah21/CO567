import java.util.Scanner;

public class Customer extends User {
    //constructor to initialise the object by calling the super class
    public Customer(String username, String password, String addressLine1, String email,String city, String postcode) {
        super(username, password, addressLine1, email, city, postcode);   
    }

    //allows customer to view shows by the date range and then view the seating chart
    public void viewShowsByDateRange(Scanner scanner) {
        boolean output = Event.viewEventsByDate(scanner);
        if (!output){
            return;
        }
        System.out.print("\nEnter Event ID to view seating chart: ");
        String eventID = scanner.nextLine();
        Event.showSeatingChart(eventID);
    }

    //allows the customer to view upcoming shows and the seating chart
    public void viewUpcomingShowsAndSeatingChart(Scanner scanner) {
        Event.viewUpcomingEvents();
        System.out.print("\nEnter Event ID to view seating chart: ");
        String eventID = scanner.nextLine();
        Event.showSeatingChart(eventID);
    }
}
