import java.time.LocalDateTime;
import java.util.*;

public class Event {
    //declaring variables
    private final String eventID;
    private String title;
    private LocalDateTime dateTime;
    private String seatingChart;

    private static List<Event> events = new ArrayList<>();

    //constructor to initialise the event object
    public Event(String eventID, String title, LocalDateTime dateTime) {
        this.eventID = eventID;
        this.title = title;
        this.dateTime = dateTime;
    }

    //sets the list of events (just to initialise some events)
    public static void setEvents(List<Event> eventList) {
        events = eventList;
    }
    
    //returns title
    public String getTitle() {
        return title;
    }

    //returns events
    public static List<Event> getEvents() {
        return events;
    }

    //returns date
    public LocalDateTime getDateTime() {
        return dateTime;
    }

    //creates a seating chart (just used for partial implementation)
    private Map<String, List<Integer>> createSeatingChart() {
        Map<String, List<Integer>> chart = new HashMap<>();
        chart.put("A", Arrays.asList(1, 2, 3, 4, 5));
        chart.put("B", Arrays.asList(6, 7, 8, 9, 10));
        chart.put("C", Arrays.asList(11, 12, 13, 14, 15));
        return chart;
    }

    //returns the seating chart as a string
    public String getSeatingChart() {
        Map<String, List<Integer>> chart = createSeatingChart();
        StringBuilder sb = new StringBuilder();
    
        for (Map.Entry<String, List<Integer>> row : chart.entrySet()) {
            sb.append("Row ").append(row.getKey()).append(": ");
            sb.append(row.getValue());
            sb.append("\n");
        }
        return sb.toString();
    }

    //displays a seating chart for a event based on its ID
    public static void showSeatingChart(String eventID) {
        for (Event event : events) {
    
            if (event.eventID.equalsIgnoreCase(eventID)) {
                System.out.println("\nSeating Chart for Event: " + event.getTitle());
                System.out.println(event.getSeatingChart());
                return;
            }
        }
        System.out.println("Event ID not found. Please try again.");
    }
    @Override
    public String toString() {
        return "Event ID: " + eventID + "\n" +
               "Title: " + title + "\n" +
               "Date & Time: " + dateTime + "\n";
    }

    //displays events in a specified date range
    public static boolean  viewEventsByDate(Scanner scanner) {
        System.out.print("Enter start date (yyyy-MM-dd): ");
        String startDateInput = scanner.nextLine();
        System.out.print("Enter end date (yyyy-MM-dd): ");
        String endDateInput = scanner.nextLine();

        try {
            LocalDateTime startDate = LocalDateTime.parse(startDateInput + "T00:00:00");
            LocalDateTime endDate = LocalDateTime.parse(endDateInput + "T23:59:59");

            System.out.println("\nEvents in the specified date range:");
            for (Event event : events) {
                if (!event.getDateTime().isBefore(startDate) && !event.getDateTime().isAfter(endDate)) {
                    System.out.println(event);
                }
            }
            return true;
        } catch (Exception e) {
            System.out.println("Invalid date format. Please try again.");
            return false;
        }
    }

    //displays upcoming events
    public static void viewUpcomingEvents() {
        System.out.println("\nUpcoming Events:");
        events.stream()
              .sorted(Comparator.comparing(Event::getDateTime))
              .forEach(System.out::println);
    }
}
