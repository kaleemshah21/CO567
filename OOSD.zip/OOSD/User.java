import java.util.*;
public class User {
    //declares attributes
    protected String username;
    protected String password;
    protected String addressLine1;
    protected String city;
    protected String postcode;
    protected String email;
    //constructor to initialise user object
    public User(String username, String password, String addressLine1, String email, String city, String postcode) {
        this.username = username;
        this.password = password;
        this.addressLine1 = addressLine1;
        this.email = email;
        this.city = city;
        this.postcode = postcode;
    }

    //returns username
    public String getUsername() {
        return username;
    }

    //returns password
    public String getPassword() {
        return password;
    }

    //allows user to login by validating against user objects
    public static User login(List<User> users, Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (username.isEmpty() || password.isEmpty()) {
            System.out.println("Username or password cannot be empty.");
            return null;
        }

        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                System.out.println("Login successful! Welcome, " + username + ".");
                return user;
            }
        }

        System.out.println("Invalid username or password. Please try again.");
        return null;
    }

    //allows a customer to signup by entering their details and validates the details
    public static void signup(List<User> users, Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        if (!isValidUsername(username)) {
            System.out.println("Invalid username. It must be at least 3 characters long.");
            return;
        }

        for (User user : users) {
            if (user.getUsername().equals(username)) {
                System.out.println("Username already taken. Please try a different one.");
                return;
            }
        }

        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        if (!isValidPassword(password)) {
            System.out.println("Invalid password. It must be 8 characters or longer.");
            return;
        }

        System.out.print("Enter address line 1: ");
        String addressLine1 = scanner.nextLine();
        if (!isValidInput(addressLine1)) {
            System.out.println("Address cannot be empty.");
            return;
        }

        System.out.print("Enter City: ");
        String city = scanner.nextLine();
        if (!isValidInput(city)) {
            System.out.println("City cannot be empty.");
            return;
        }

        System.out.print("Enter Postcode: ");
        String postcode = scanner.nextLine();
        if (!isValidPostcode(postcode)) {
            System.out.println("Invalid postcode. It must be at least 3 characters long.");
            return;
        }

        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        if (!isValidEmail(email)) {
            System.out.println("Invalid email format.");
            return;
        }

        Customer newCustomer = new Customer(username, password, addressLine1, email, city, postcode);
        users.add(newCustomer);
        System.out.println("Signup successful! Welcome, " + username + ".");
    }

    // Validation methods
    private static boolean isValidUsername(String username) {
        return username.length() >= 3;
    }

    private static boolean isValidPassword(String password) {
        return password.length() >= 8;
    }

    private static boolean isValidPostcode(String postcode) {
        return postcode.length() >= 3;
    }

    private static boolean isValidInput(String input) {
        return input != null && !input.trim().isEmpty();
    }

    private static boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }
}


